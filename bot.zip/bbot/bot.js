const Discord = require("discord.js");
const client = new Discord.Client();
const config = require("./config.json");
require('events').EventEmitter.defaultMaxListeners = 0;

var CronJob = require('cron').CronJob;
var cron = require('node-cron');


client.on("ready", () => {
 console.log(`Bot has started, with ${client.users.size} users, in ${client.channels.size} channels of ${client.guilds.size} guilds.`); 
 client.user.setActivity(`use +help to view the command list`);
});

client.on("guildCreate", guild => {
  console.log(`New guild joined: ${guild.name} (id: ${guild.id}). This guild has ${guild.memberCount} members!`);
  client.user.setActivity(`use +help to view the command list`);
});

client.on("guildDelete", guild => {
  console.log(`I have been removed from: ${guild.name} (id: ${guild.id})`);
  client.user.setActivity(`use +help to view the command list`);
});



	
	
	


client.on("message", async message => {
  
  
  if(message.author.bot) return;
 
  
  const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
 
	
if(!message.content.startsWith(config.prefix))return;
	



  switch (command) {
	case"neu":
    if(!message.member.roles.some(r=>["Moderator"].includes(r.name)) )
		return message.reply("go away me no work");
            process.setMaxListeners(0);
            let zwei = message.guild.roles.find(r => r.name == 'ME-TagPC2');
            let eins = message.guild.roles.find(r => r.name == 'ME-TagPC1');
            let nulll = message.guild.roles.find(r => r.name == 'ME-TagPC0');

            message.guild.members.forEach(member => member.addRole(zwei));
            message.guild.members.forEach(member => member.removeRole(eins));
            message.guild.members.forEach(member => member.removeRole(nulll));
            return message.channel.send(`**${message.author.username}**, daily PCs got reseted`);
        break;
	case"test":
		return message.channel.send("works.");
	break;
  }
  
});

client.login(config.token);